const STAGES = [
  { min: 1, max: 10, label: "Lv1〜10", next: "Lv11" },
  { min: 11, max: 20, label: "Lv11〜20", next: "Lv21" },
  { min: 21, max: 30, label: "Lv21〜30", next: "Lv31" },
  { min: 31, max: 40, label: "Lv31〜40", next: "Lv41" },
  { min: 41, max: 65, label: "Lv41〜キャンペーン終了", next: "Mapping開始" },
  { min: 66, max: 75, label: "Mapping開始", next: "Early Endgame" },
  { min: 76, max: 90, label: "Early Endgame", next: "Endgame完成" },
  { min: 91, max: 100, label: "Endgame完成", next: "完成後の更新" }
];

const byId = (id) => document.getElementById(id);
const text = (value) => value === null || value === undefined || value === "" ? "確認中" : String(value);
const stageIndexFor = (level) => Math.max(0, STAGES.findIndex((stage) => level >= stage.min && level <= stage.max));
// Resolve which of the build's own leveling stages applies at the current level.
// Builds written against the fixed bands match the STAGES label exactly and never
// reach the fallbacks: a level range written in the label (e.g. "Lv1〜13"), then
// the band position clamped to the build's own stage count.
function resolveBuildStageIndex(index) {
  const stages = build?.levelingStages || [];
  if (!stages.length) return -1;
  const exact = stages.findIndex((item) => item.label === STAGES[index].label);
  if (exact >= 0) return exact;
  const byRange = stages.findIndex((item) => {
    const range = /Lv\s*(\d+)\s*[〜~～\-–]\s*(\d+)/.exec(item.label || "");
    return range && level >= Number(range[1]) && level <= Number(range[2]);
  });
  return byRange >= 0 ? byRange : Math.min(index, stages.length - 1);
}
let build;
let level = 1;
let selectedTrouble = null;
const PROGRESS_ITEMS = [
  ["skill", "現在段階のメインスキルを用意した"],
  ["support", "案内されたサポートを確認した"],
  ["passive", "現在段階のパッシブルートを確認した"],
  ["weapon", "武器・主力装備を見直した"],
  ["armor", "防具と移動速度を見直した"],
  ["resistance", "属性耐性を確認した"],
  ["mechanic", "ビルド固有の操作順を試した"]
];

function pathInfo() {
  const parts = location.pathname.split("/").filter(Boolean);
  const buildsIndex = parts.indexOf("builds");
  return { classSlug: parts[buildsIndex + 1], slug: parts[buildsIndex + 2] };
}

function fact(label, value) {
  const wrapper = document.createElement("div");
  wrapper.className = "fact";
  const small = document.createElement("small");
  const bold = document.createElement("b");
  small.textContent = label;
  bold.textContent = value === null ? "確認中" : value;
  wrapper.append(small, bold);
  return wrapper;
}

function stageItem(label, value) {
  const item = document.createElement("div");
  item.className = "stage-item";
  const small = document.createElement("small");
  const paragraph = document.createElement("p");
  small.textContent = label;
  if (value) {
    paragraph.textContent = value;
    item.append(small, paragraph);
  } else {
    const badge = document.createElement("span");
    badge.className = "pending";
    badge.textContent = "確認中";
    paragraph.textContent = "検証できた情報を順次登録します。未確認の内容は掲載しません。";
    item.append(small, badge, paragraph);
  }
  return item;
}

function renderStage(index, scroll = false) {
  const target = build ? resolveBuildStageIndex(index) : index;
  const details = [...document.querySelectorAll("#roadmap details[data-stage-index]")];
  details.forEach((item, itemIndex) => {
    const current = itemIndex === target;
    item.open = current;
    item.toggleAttribute("data-current", current);
    const marker = item.querySelector(".current-stage-marker");
    if (marker) marker.hidden = !current;
  });
  if (scroll) details[target]?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderNow(index) {
  const stage = STAGES[index];
  byId("now-stage").textContent = stage.label;
  byId("now-next").textContent = `次の目標：${stage.next}`;
  const stagePosition = resolveBuildStageIndex(index);
  const currentStage = stagePosition >= 0 ? build.levelingStages[stagePosition] : undefined;
  const stageLink = byId("now-stage-detail");
  if (stageLink) stageLink.href = `#roadmap-stage-${stagePosition >= 0 ? stagePosition : index}`;
  const verifiedActions = currentStage?.nowActions;
  const actions = verifiedActions || [
    "現在レベルと育成段階が合っているか確認する",
    "確認済みのスキル・パッシブ情報が登録されるまで『確認中』を目印にする",
    "装備更新前に必要レベルと、このビルドの対応パッチを確認する"
  ];
  byId("now-source-label").textContent = verifiedActions ? "掲載資料から整理した優先行動" : "この段階は確認中";
  const actionElements = [...document.querySelectorAll("[data-now-action]")];
  actionElements.forEach((element, actionIndex) => { element.textContent = actions[actionIndex]; });
  const guidance = byId("now-action-guidance");
  if (guidance) {
    guidance.replaceChildren();
    const detail = currentStage?.actionGuidance;
    const action = Number.isInteger(detail?.actionIndex) ? actionElements[detail.actionIndex] : null;
    guidance.hidden = !action || !verifiedActions?.[detail.actionIndex] || !detail.what || !detail.where || !detail.url;
    if (!guidance.hidden) {
      // Keep the source and its exact guide stage with the action they explain.
      // Spanning the complete row also works with the one-column mobile layout.
      action.parentElement.append(guidance);
      guidance.style.gridColumn = "1 / -1";
      guidance.style.margin = "0";
      guidance.append(document.createTextNode(`確認する段階・箇所：${detail.where}。${detail.what}を確認。`));
      const link = document.createElement("a");
      link.href = detail.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = "該当する元ガイドを見る";
      guidance.append(" ", link);
    }
  }
}

function renderProgress() {
  const wrapper = byId("progress-checks");
  wrapper.replaceChildren();
  const storageKey = `poe2:navi:progress:${build.id}:${stageIndexFor(level)}`;
  // Preserve pre-migration checks on the saved character's current stage.
  const legacyKey=`poe2:navi:progress:${build.id}`;
  if(!localStorage.getItem(storageKey)&&!localStorage.getItem(`${legacyKey}:migrated`)){
    const legacy=localStorage.getItem(legacyKey);
    if(legacy){const oldLevel=Number(localStorage.getItem(`poe2:navi:level:${build.id}`))||1;localStorage.setItem(`poe2:navi:progress:${build.id}:${stageIndexFor(oldLevel)}`,legacy);localStorage.setItem(`${legacyKey}:migrated`,'true');}
  }
  const saved = JSON.parse(localStorage.getItem(storageKey) || "{}");
  PROGRESS_ITEMS.forEach(([id, label]) => {
    const row = document.createElement("label");
    row.className = "progress-check";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = Boolean(saved[id]);
    const text = document.createElement("span");
    text.textContent = label;
    input.addEventListener("change", () => {
      saved[id] = input.checked;
      localStorage.setItem(storageKey, JSON.stringify(saved));
      updateProgress(saved);
    });
    row.append(input, text);
    wrapper.append(row);
  });
  updateProgress(saved);
}

function updateProgress(saved) {
  const complete = PROGRESS_ITEMS.filter(([id]) => saved[id]).length;
  const percent = Math.round((complete / PROGRESS_ITEMS.length) * 100);
  byId("progress-percent").textContent = `${percent}%`;
  byId("progress-bar").style.width = `${percent}%`;
  const next = PROGRESS_ITEMS.find(([id]) => !saved[id]);
  byId("progress-next").textContent = next ? `次にやること：${next[1]}` : "現在段階の確認は完了です。次のロードマップ段階へ進みましょう。";
}

// Keeps ?level= in the address bar only when it carries information: after the reader changes
// the level, or when they arrived with one. Opening a page never adds it, and Lv1 (the default)
// is dropped, so shared links and analytics stay on the clean canonical URL.
function syncLevelParam(fromUser) {
  const currentUrl = new URL(location.href);
  if (!fromUser && !currentUrl.searchParams.has("level")) return;
  if (level === 1) currentUrl.searchParams.delete("level");
  else currentUrl.searchParams.set("level", String(level));
  if (currentUrl.href !== location.href) history.replaceState(history.state, "", currentUrl);
}

function setLevel(value, fromUser = true) {
  level = Math.max(1, Math.min(100, Math.trunc(Number(value) || 1)));
  byId("level-input").value = level;
  byId("level-range").value = level;
  byId("level-output").value = `Lv${level}`;
  localStorage.setItem(`poe2:navi:level:${build.id}`, String(level));
  localStorage.setItem("poe2:navi:quick-level", String(level));
  const gearCheckLink = byId("gear-check-link");
  if (gearCheckLink) {
    gearCheckLink.href = `/gear-check/?build=${encodeURIComponent(build.id)}&level=${level}&concern=purchase`;
  }
  const uniqueGearLink = document.querySelector("[data-unique-gear-level]");
  if (uniqueGearLink) {
    const params = new URLSearchParams({ build: build.id, level: String(level) });
    uniqueGearLink.href = `/guides/unique-gear/?${params}#purchase-${build.id}`;
  }
  syncLevelParam(fromUser);
  const index = stageIndexFor(level);
  localStorage.setItem("poe2:navi:lastViewedStage", String(index));
  for (const link of document.querySelectorAll('[data-simulator-level]')) link.href = `/simulator/?build=${encodeURIComponent(build.id)}&level=${level}&from=guide`;
  renderNow(index);
  renderStage(index);
  renderProgress();
  localStorage.setItem('poe2:navi:last-access', new Date().toISOString());
  if (selectedTrouble) renderTrouble(selectedTrouble);
}

function renderTrouble(type) {
  selectedTrouble = type;
  const stagePosition = resolveBuildStageIndex(stageIndexFor(level));
  const stage = stagePosition >= 0 ? build.levelingStages?.[stagePosition] : undefined;
  if (!stage) return;
  const manaWeakness = (build.weaknesses || []).find((item) => /マナ|Mana/i.test(item));
  const plans = {
    death: [["最優先", stage.gearPriority], ["次", stage.replaceGear], ["その次", stage.caution]],
    damage: [["最優先", `主力「${stage.mainSkill}」が現在段階どおりか確認`], ["次", stage.supports], ["その次", stage.passivePriority]],
    mana: manaWeakness ? [["最優先", manaWeakness], ["次", "主力と補助スキルを必要以上に連打していないか確認"], ["その次", stage.replaceGear]] : [["最優先", "このビルド固有のマナ対策は資料で確認できていません"], ["次", "主力・サポートの必要条件と消費をゲーム内で確認"], ["その次", "装備変更前後でマナ維持を比較"]],
    boss: [["最優先", `単体戦で使うスキルを確認：${stage.mainSkill}`], ["次", stage.supports], ["その次", stage.caution]],
    speed: [["最優先", stage.mainSkill], ["次", stage.gearPriority], ["その次", stage.transitionCondition]],
    gear: [["最優先", stage.replaceGear], ["次", stage.gearPriority], ["その次", "固定相場ではなく、現在出品を同条件で比較"]]
  };
  document.querySelectorAll("[data-trouble]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.trouble === type)));
  const result = byId("trouble-result");
  result.replaceChildren();
  const list = document.createElement("ol"); list.className = "trouble-plan";
  plans[type].forEach(([rank, action]) => { const li=document.createElement("li"); const b=document.createElement("b"); const span=document.createElement("span"); b.textContent=rank; span.textContent=action; li.append(b,span); list.append(li); });
  const note=document.createElement("p"); note.className="disclaimer"; note.textContent=`${stage.label}の確認済みデータを基準に表示しています。一般項目はその旨を明記しています。`;
  result.append(list,note);
  const gearLink=document.createElement('a');gearLink.className='button';gearLink.href=`/gear-check/?build=${encodeURIComponent(build.id)}&level=${level}&concern=${type==='gear'?'purchase':type}`;gearLink.textContent='予算も指定して装備を確認';result.append(gearLink);
  localStorage.setItem(`poe2:navi:trouble:${build.id}`, type);
}

function fillList(id, values, emptyText) {
  const list = byId(id);
  list.replaceChildren();
  (values.length ? values : [emptyText]).forEach((value) => {
    const item = document.createElement("li");
    item.textContent = value;
    list.append(item);
  });
}

function renderSources() {
  const list = byId("source-list");
  list.replaceChildren();
  if (!build.sources?.length) {
    const item = document.createElement("li");
    item.textContent = "情報源を確認中です。";
    list.append(item);
    return;
  }
  build.sources.forEach((source) => {
    const item = document.createElement("li");
    const link = document.createElement("a");
    const meta = document.createElement("span");
    link.href = source.url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = source.name;
    meta.textContent = `${source.type}・確認日 ${source.checkedAt}`;
    item.append(link, meta);
    list.append(item);
  });
}

// Accepts the per-build file ({build, related}, data/builds/<class>/<slug>.json) or the full
// builds.json array, and returns the page's build with its same-class related builds.
function pickBuild(data, info) {
  if (!data) return {};
  if (!Array.isArray(data)) return data.build?.classSlug === info.classSlug && data.build?.slug === info.slug ? data : {};
  const found = data.find((item) => item.classSlug === info.classSlug && item.slug === info.slug);
  return { build: found, related: found ? data.filter((item) => item.status !== "draft" && item.className === found.className && item.id !== found.id).slice(0, 3) : [] };
}

function renderBuild(relatedBuilds) {
  document.title = build.seoTitle || `PoE2 ${build.version} ${build.name} ビルド｜Lv1〜Endgame育成`;
  byId("build-name").textContent = `PoE2 ${build.name} ビルド｜${build.version}育成`;
  byId("build-class").textContent = `${build.className} / ${text(build.ascendancy)}`;
  byId("build-skill").textContent = `メインスキル：${text(build.mainSkill)}`;
  byId("breadcrumb-name").textContent = build.name;
  byId("breadcrumb-class").textContent = build.className;
  byId("breadcrumb-class").href = `/classes/${build.classSlug}/`;
  localStorage.setItem("poe2:navi:selected-class", build.className);
  localStorage.setItem("poe2:navi:selected-build", build.id);
  const facts = byId("fact-grid");
  facts.replaceChildren();
  [
    ["対応パッチ", build.version], ["育成手順の原典照合日", build.updatedAt], ["確認状態", build.status === "verified" ? "主要情報確認済み" : build.status === "partial" ? "不足箇所を各段階に表示" : "対応パッチを再確認中"], ["掲載中の育成段階", `${build.levelingStages?.length || 0}/8`]
  ].forEach(([label, value]) => facts.append(fact(label, value)));
  if (build.mainSkillTiming) {
    facts.append(fact("主力スキル使用条件", build.mainSkillTiming.available), fact("主力への切替目安", build.mainSkillTiming.recommendedSwitch));
  }
  renderSources();
  renderProgress();

  const related = byId("related-links");
  const addRelated = (href, label) => {
    if (related.querySelector(`a[href="${href}"]`) || related.childElementCount >= 3) return;
    const link = document.createElement("a");
    link.href = href;
    link.textContent = label;
    related.append(link);
  };
  relatedBuilds.forEach((item) => {
    addRelated(`/builds/${item.classSlug}/${item.slug}/`, item.name);
  });
  if (!related.childElementCount) {
    addRelated("/builds/", "ビルド一覧へ戻る");
  }
  [["/gear-check/", "このビルドで装備診断"], ["/beginner-guide/", "初心者ガイド"], ["/dictionary/", "用語辞典"]].forEach(([href, label]) => {
    addRelated(href, label);
  });

  const urlLevel = Number(new URLSearchParams(location.search).get("level"));
  const savedLevel = Number(localStorage.getItem(`poe2:navi:level:${build.id}`));
  setLevel(urlLevel || savedLevel || 1, false);
}

function bindEvents() {
  const savedStages=JSON.parse(localStorage.getItem(`poe2:navi:stages:${build.id}`)||'{}');
  document.querySelectorAll('#roadmap details').forEach((details,index)=>{
    const check=details.querySelector('.stage-complete input');
    if(!check)return;
    check.checked=Boolean(savedStages[index]);
    check.addEventListener('change',()=>{savedStages[index]=check.checked;localStorage.setItem(`poe2:navi:stages:${build.id}`,JSON.stringify(savedStages));});
  });
  const commitLevelInput = () => {
    const input = byId("level-input");
    const value = input.value.trim();
    const next = value !== "" && Number.isFinite(Number(value)) ? Math.max(1, Math.min(100, Math.trunc(Number(value)))) : level;
    input.value = next;
    if (next !== level) setLevel(next);
  };
  byId("level-input").addEventListener("change", commitLevelInput);
  byId("level-input").addEventListener("blur", commitLevelInput);
  byId("level-input").addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); commitLevelInput(); }
  });
  byId("level-range").addEventListener("input", (event) => setLevel(event.target.value));
  byId("level-minus").addEventListener("click", () => setLevel(level - 1));
  byId("level-plus").addEventListener("click", () => setLevel(level + 1));
  document.querySelectorAll("[data-trouble]").forEach((button) => button.addEventListener("click", () => renderTrouble(button.dataset.trouble)));
  byId("menu-button").addEventListener("click", () => {
    const nav = byId("site-nav");
    const open = nav.classList.toggle("open");
    byId("menu-button").setAttribute("aria-expanded", String(open));
  });
}

function revealNoteReferral() {
  const params = new URLSearchParams(location.search);
  const fromNote = params.get("utm_source") === "note" || document.referrer.startsWith("https://note.com/");
  const guide = byId("note-referral-guide");
  if (fromNote && guide) guide.hidden = false;
}

async function init() {
  try {
    const info = pathInfo();
    // Only this build's data (~20KB); shared with build-ux.js so it is downloaded once per page.
    const data = await (window.poe2BuildsRequest ||= fetch(`/data/builds/${info.classSlug}/${info.slug}.json`).then((response) => {
      if (response.status === 404) return null;
      if (!response.ok) throw new Error("ビルドデータを読み込めませんでした");
      return response.json();
    }));
    const picked = pickBuild(data, info);
    build = picked.build;
    if (!build) {
      location.replace("/404.html");
      return;
    }
    renderBuild(picked.related ?? []);
    bindEvents();
    revealNoteReferral();
    const savedTrouble = localStorage.getItem(`poe2:navi:trouble:${build.id}`);
    if (savedTrouble) renderTrouble(savedTrouble);
  } catch (error) {
    byId("build-name").textContent = "データを読み込めませんでした";
    console.error(error);
  }
}

init();
