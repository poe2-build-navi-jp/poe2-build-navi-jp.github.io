const STAGES = [
  { min: 1, max: 10, label: "Lv1〜10", next: "Lv11" },
  { min: 11, max: 20, label: "Lv11〜20", next: "Lv21" },
  { min: 21, max: 30, label: "Lv21〜30", next: "Lv31" },
  { min: 31, max: 40, label: "Lv31〜40", next: "Lv41" },
  { min: 41, max: 65, label: "Lv41〜キャンペーン終了", next: "Mapping開始" },
  { min: 66, max: 75, label: "Mapping開始", next: "Early Endgame" },
  { min: 76, max: 90, label: "Early Endgame", next: "Endgame完成" },
  { min: 91, max: 100, label: "Endgame完成", next: "完成後の更新" }
];

const byId = (id) => document.getElementById(id);
const text = (value) => value === null || value === undefined || value === "" ? "確認中" : String(value);
const stageIndexFor = (level) => Math.max(0, STAGES.findIndex((stage) => level >= stage.min && level <= stage.max));
let build;
let level = 1;
let selectedTrouble = null;
const PROGRESS_ITEMS = [
  ["skill", "現在段階のメインスキルを用意した"],
  ["support", "案内されたサポートを確認した"],
  ["passive", "現在段階のパッシブルートを確認した"],
  ["weapon", "武器・主力装備を見直した"],
  ["armor", "防具と移動速度を見直した"],
  ["resistance", "属性耐性を確認した"],
  ["mechanic", "ビルド固有の操作順を試した"]
];

function pathInfo() {
  const parts = location.pathname.split("/").filter(Boolean);
  const buildsIndex = parts.indexOf("builds");
  return { classSlug: parts[buildsIndex + 1], slug: parts[buildsIndex + 2] };
}

function fact(label, value) {
  const wrapper = document.createElement("div");
  wrapper.className = "fact";
  const small = document.createElement("small");
  const bold = document.createElement("b");
  small.textContent = label;
  bold.textContent = value === null ? "確認中" : value;
  wrapper.append(small, bold);
  return wrapper;
}

function stageItem(label, value) {
  const item = document.createElement("div");
  item.className = "stage-item";
  const small = document.createElement("small");
  const paragraph = document.createElement("p");
  small.textContent = label;
  if (value) {
    paragraph.textContent = value;
    item.append(small, paragraph);
  } else {
    const badge = document.createElement("span");
    badge.className = "pending";
    badge.textContent = "確認中";
    paragraph.textContent = "検証できた情報を順次登録します。未確認の内容は掲載しません。";
    item.append(small, badge, paragraph);
  }
  return item;
}

function renderStage(index, scroll = false) {
  const details = [...document.querySelectorAll("#roadmap details[data-stage-index]")];
  details.forEach((item, itemIndex) => {
    const current = itemIndex === index;
    item.open = current;
    item.toggleAttribute("data-current", current);
    const marker = item.querySelector(".current-stage-marker");
    if (marker) marker.hidden = !current;
  });
  if (scroll) details[index]?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderNow(index) {
  const stage = STAGES[index];
  byId("now-stage").textContent = stage.label;
  byId("now-next").textContent = `次の目標：${stage.next}`;
  const verifiedActions = build.levelingStages?.find((item) => item.label === stage.label)?.nowActions;
  const actions = verifiedActions || [
    "現在レベルと育成段階が合っているか確認する",
    "確認済みのスキル・パッシブ情報が登録されるまで『確認中』を目印にする",
    "装備更新前に必要レベルと、このビルドの対応パッチを確認する"
  ];
  byId("now-source-label").textContent = verifiedActions ? "掲載資料から整理した優先行動" : "この段階は確認中";
  document.querySelectorAll("[data-now-action]").forEach((element, actionIndex) => { element.textContent = actions[actionIndex]; });
}

function renderProgress() {
  const wrapper = byId("progress-checks");
  wrapper.replaceChildren();
  const storageKey = `poe2:navi:progress:${build.id}:${stageIndexFor(level)}`;
  // Preserve pre-migration checks on the saved character's current stage.
  const legacyKey=`poe2:navi:progress:${build.id}`;
  if(!localStorage.getItem(storageKey)&&!localStorage.getItem(`${legacyKey}:migrated`)){
    const legacy=localStorage.getItem(legacyKey);
    if(legacy){const oldLevel=Number(localStorage.getItem(`poe2:navi:level:${build.id}`))||1;localStorage.setItem(`poe2:navi:progress:${build.id}:${stageIndexFor(oldLevel)}`,legacy);localStorage.setItem(`${legacyKey}:migrated`,'true');}
  }
  const saved = JSON.parse(localStorage.getItem(storageKey) || "{}");
  PROGRESS_ITEMS.forEach(([id, label]) => {
    const row = document.createElement("label");
    row.className = "progress-check";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = Boolean(saved[id]);
    const text = document.createElement("span");
    text.textContent = label;
    input.addEventListener("change", () => {
      saved[id] = input.checked;
      localStorage.setItem(storageKey, JSON.stringify(saved));
      updateProgress(saved);
    });
    row.append(input, text);
    wrapper.append(row);
  });
  updateProgress(saved);
}

function updateProgress(saved) {
  const complete = PROGRESS_ITEMS.filter(([id]) => saved[id]).length;
  const percent = Math.round((complete / PROGRESS_ITEMS.length) * 100);
  byId("progress-percent").textContent = `${percent}%`;
  byId("progress-bar").style.width = `${percent}%`;
  const next = PROGRESS_ITEMS.find(([id]) => !saved[id]);
  byId("progress-next").textContent = next ? `次にやること：${next[1]}` : "現在段階の確認は完了です。次のロードマップ段階へ進みましょう。";
}

function setLevel(value) {
  level = Math.max(1, Math.min(100, Math.trunc(Number(value) || 1)));
  byId("level-input").value = level;
  byId("level-range").value = level;
  byId("level-output").value = `Lv${level}`;
  localStorage.setItem(`poe2:navi:level:${build.id}`, String(level));
  localStorage.setItem("poe2:navi:quick-level", String(level));
  const gearCheckLink = byId("gear-check-link");
  if (gearCheckLink) {
    gearCheckLink.href = `/gear-check/?build=${encodeURIComponent(build.id)}&level=${level}&concern=purchase`;
  }
  const currentUrl = new URL(location.href);
  if (currentUrl.searchParams.get("level") !== String(level)) {
    currentUrl.searchParams.set("level", String(level));
    history.replaceState(history.state, "", currentUrl);
  }
  const index = stageIndexFor(level);
  renderNow(index);
  renderStage(index);
  renderProgress();
  localStorage.setItem('poe2:navi:last-access', new Date().toISOString());
  if (selectedTrouble) renderTrouble(selectedTrouble);
}

function renderTrouble(type) {
  selectedTrouble = type;
  const stage = build.levelingStages?.[stageIndexFor(level)];
  if (!stage) return;
  const manaWeakness = (build.weaknesses || []).find((item) => /マナ|Mana/i.test(item));
  const plans = {
    death: [["最優先", stage.gearPriority], ["次", stage.replaceGear], ["その次", stage.caution]],
    damage: [["最優先", `主力「${stage.mainSkill}」が現在段階どおりか確認`], ["次", stage.supports], ["その次", stage.passivePriority]],
    mana: manaWeakness ? [["最優先", manaWeakness], ["次", "主力と補助スキルを必要以上に連打していないか確認"], ["その次", stage.replaceGear]] : [["最優先", "このビルド固有のマナ対策は資料で確認できていません"], ["次", "主力・サポートの必要条件と消費をゲーム内で確認"], ["その次", "装備変更前後でマナ維持を比較"]],
    boss: [["最優先", `単体戦で使うスキルを確認：${stage.mainSkill}`], ["次", stage.supports], ["その次", stage.caution]],
    speed: [["最優先", stage.mainSkill], ["次", stage.gearPriority], ["その次", stage.transitionCondition]],
    gear: [["最優先", stage.replaceGear], ["次", stage.gearPriority], ["その次", "固定相場ではなく、現在出品を同条件で比較"]]
  };
  document.querySelectorAll("[data-trouble]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.trouble === type)));
  const result = byId("trouble-result");
  result.replaceChildren();
  const list = document.createElement("ol"); list.className = "trouble-plan";
  plans[type].forEach(([rank, action]) => { const li=document.createElement("li"); const b=document.createElement("b"); const span=document.createElement("span"); b.textContent=rank; span.textContent=action; li.append(b,span); list.append(li); });
  const note=document.createElement("p"); note.className="disclaimer"; note.textContent=`${stage.label}の確認済みデータを基準に表示しています。一般項目はその旨を明記しています。`;
  result.append(list,note);
  const gearLink=document.createElement('a');gearLink.className='button';gearLink.href=`/gear-check/?build=${encodeURIComponent(build.id)}&level=${level}&concern=${type==='gear'?'purchase':type}`;gearLink.textContent='予算も指定して装備を確認';result.append(gearLink);
  localStorage.setItem(`poe2:navi:trouble:${build.id}`, type);
}

function fillList(id, values, emptyText) {
  const list = byId(id);
  list.replaceChildren();
  (values.length ? values : [emptyText]).forEach((value) => {
    const item = document.createElement("li");
    item.textContent = value;
    list.append(item);
  });
}

function renderSources() {
  const list = byId("source-list");
  list.replaceChildren();
  if (!build.sources?.length) {
    const item = document.createElement("li");
    item.textContent = "情報源を確認中です。";
    list.append(item);
    return;
  }
  build.sources.forEach((source) => {
    const item = document.createElement("li");
    const link = document.createElement("a");
    const meta = document.createElement("span");
    link.href = source.url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = source.name;
    meta.textContent = `${source.type}・確認日 ${source.checkedAt}`;
    item.append(link, meta);
    list.append(item);
  });
}

function renderBuild(builds) {
  document.title = build.seoTitle || `PoE2 ${build.version} ${build.name} ビルド｜Lv1〜Endgame育成`;
  byId("build-name").textContent = `PoE2 ${build.name} ビルド｜${build.version}育成`;
  byId("build-class").textContent = `${build.className} / ${text(build.ascendancy)}`;
  byId("build-skill").textContent = `メインスキル：${text(build.mainSkill)}`;
  byId("breadcrumb-name").textContent = build.name;
  byId("breadcrumb-class").textContent = build.className;
  byId("breadcrumb-class").href = `/classes/${build.classSlug}/`;
  localStorage.setItem("poe2:navi:selected-class", build.className);
  localStorage.setItem("poe2:navi:selected-build", build.id);
  const facts = byId("fact-grid");
  facts.replaceChildren();
  [
    ["対応パッチ", build.version], ["最終確認日", build.updatedAt], ["確認状態", build.status === "verified" ? "主要情報確認済み" : build.status === "partial" ? "不足箇所を各段階に表示" : "対応パッチを再確認中"], ["確認済み段階", `${build.levelingStages?.length || 0}/8`]
  ].forEach(([label, value]) => facts.append(fact(label, value)));
  renderSources();
  renderProgress();

  const related = byId("related-links");
  const addRelated = (href, label) => {
    if (related.querySelector(`a[href="${href}"]`) || related.childElementCount >= 3) return;
    const link = document.createElement("a");
    link.href = href;
    link.textContent = label;
    related.append(link);
  };
  builds.filter((item) => item.status !== "draft" && item.className === build.className && item.id !== build.id).slice(0, 3).forEach((item) => {
    addRelated(`/builds/${item.classSlug}/${item.slug}/`, item.name);
  });
  if (!related.childElementCount) {
    addRelated("/builds/", "ビルド一覧へ戻る");
  }
  [["/gear-check/", "このビルドで装備診断"], ["/beginner-guide/", "初心者ガイド"], ["/dictionary/", "用語辞典"]].forEach(([href, label]) => {
    addRelated(href, label);
  });

  const urlLevel = Number(new URLSearchParams(location.search).get("level"));
  const savedLevel = Number(localStorage.getItem(`poe2:navi:level:${build.id}`));
  setLevel(urlLevel || savedLevel || 1);
}

function bindEvents() {
  const savedStages=JSON.parse(localStorage.getItem(`poe2:navi:stages:${build.id}`)||'{}');
  document.querySelectorAll('#roadmap details').forEach((details,index)=>{
    const check=details.querySelector('.stage-complete input');
    if(!check)return;
    check.checked=Boolean(savedStages[index]);
    check.addEventListener('change',()=>{savedStages[index]=check.checked;localStorage.setItem(`poe2:navi:stages:${build.id}`,JSON.stringify(savedStages));});
  });
  byId("level-input").addEventListener("input", (event) => setLevel(event.target.value));
  byId("level-range").addEventListener("input", (event) => setLevel(event.target.value));
  byId("level-minus").addEventListener("click", () => setLevel(level - 1));
  byId("level-plus").addEventListener("click", () => setLevel(level + 1));
  document.querySelectorAll("[data-trouble]").forEach((button) => button.addEventListener("click", () => renderTrouble(button.dataset.trouble)));
  byId("menu-button").addEventListener("click", () => {
    const nav = byId("site-nav");
    const open = nav.classList.toggle("open");
    byId("menu-button").setAttribute("aria-expanded", String(open));
  });
}

function revealNoteReferral() {
  const params = new URLSearchParams(location.search);
  const fromNote = params.get("utm_source") === "note" || document.referrer.startsWith("https://note.com/");
  const guide = byId("note-referral-guide");
  if (fromNote && guide) guide.hidden = false;
}

async function init() {
  try {
    const response = await fetch("/data/builds.json");
    if (!response.ok) throw new Error("ビルドデータを読み込めませんでした");
    const builds = await response.json();
    const info = pathInfo();
    build = builds.find((item) => item.classSlug === info.classSlug && item.slug === info.slug);
    if (!build) {
      location.replace("/404.html");
      return;
    }
    renderBuild(builds);
    bindEvents();
    revealNoteReferral();
    const savedTrouble = localStorage.getItem(`poe2:navi:trouble:${build.id}`);
    if (savedTrouble) renderTrouble(savedTrouble);
  } catch (error) {
    byId("build-name").textContent = "データを読み込めませんでした";
    console.error(error);
  }
}

init();
