import * as engine from './simulator-engine/v0.0.46/pobr_wasm.js';
import {validRequest} from './simulator-model.js?v=fdda84f09b';
import {stageVerifiedData} from './simulator-engine-loader.js?v=f85f6c4910';

const base = new URL('./simulator-engine/v0.0.46/', import.meta.url);
let ready, dataFiles, runtime, gems, uniques, minions;
let loadedBytes=0,totalBytes=0;
// These engine rows are placeholders, not usable skills. Retain them for existing saves.
const internalSkills=new Set(['DoLiterallyNothingPlayer','UnusablePlayer','PlaytestAttack','PlaytestSlam','PlaytestSpell']);
const progress=()=>postMessage({progress:`計算データを準備中：${(loadedBytes/1000000).toFixed(1)} / ${(totalBytes/1000000).toFixed(1)} MB（保存済みデータも利用）`});
const digest = async bytes => [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(n=>n.toString(16).padStart(2,'0')).join('');
async function get(name) {
  const response = await fetch(new URL(name,base));
  if (!response.ok) throw new Error(`計算データの取得に失敗しました（${response.status}）。再読み込みしてください。`);
  return response;
}
async function unpack(bundle) {
  const chunks = await Promise.all(bundle.parts.map(async part => {
    let cache;try{cache=await caches.open('poe2-simulator-engine-v1');}catch{}
    const url=new URL(part.file,base).href;
    let response;try{response=await cache?.match(url);}catch{}
    let bytes=response?new Uint8Array(await response.arrayBuffer()):null;
    if(!bytes || bytes.length!==part.bytes || await digest(bytes)!==part.sha256){
      bytes=new Uint8Array(await (await get(part.file)).arrayBuffer());
      if(bytes.length===part.bytes && await digest(bytes)===part.sha256)try{await cache?.put(url,new Response(bytes));}catch{}
    }
    loadedBytes+=bytes.length;progress();
    if (bytes.length !== part.bytes || await digest(bytes) !== part.sha256) throw new Error('計算データの整合性を確認できません。再読み込みしてください。');
    return bytes;
  }));
  const compressed = new Uint8Array(bundle.bytes);
  let offset = 0; for (const chunk of chunks) {compressed.set(chunk,offset); offset += chunk.length;}
  if (await digest(compressed) !== bundle.sha256) throw new Error('計算データが欠けています。');
  return new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip')));
}
async function boot() {
  postMessage({progress:'計算エンジンとゲームデータを読み込んでいます（初回約9.3MB）…'});
  runtime = await (await get('runtime.json?v=2ec49b4ef3')).json();
  totalBytes=runtime.wasm.bytes+runtime.data.bytes;progress();
  const [wasm,dataResponse] = await Promise.all([unpack(runtime.wasm),unpack(runtime.data)]);
  postMessage({progress:'計算エンジンを起動しています…'});
  await engine.default({module_or_path:await wasm.arrayBuffer()});
  if (engine.schemaVersion() !== 19 || runtime.schema !== 19) throw new Error('計算エンジンの版が一致しません。');
  postMessage({progress:'ゲームデータを展開しています…'});
  const data = await dataResponse.json();
  if (data.version !== runtime.dataVersion) throw new Error('ゲームデータの版が一致しません。');
  try {
    dataFiles = await stageVerifiedData(engine,data);
    gems = JSON.parse(engine.gemCatalogJson()).map(gem=>internalSkills.has(gem.skill_id)?{...gem,ui_hidden:true}:gem);
    uniques = JSON.parse(engine.uniqueCatalogJson());
    minions = JSON.parse(engine.minionCatalogJson());
  }
  catch(error) {
    if(error.message==='ENGINE_DATA_INTEGRITY')throw new Error('計算データの整合性を確認できません。再読み込みしてください。');
    // A trapped instance can retain invalid Rust state. Only a new worker may retry boot.
    error.code='ENGINE_STARTUP_FAILURE';
    throw error;
  }
}
const treeCache=new Map();
function tree(version) {
  const path = version && version !== '0_5' ? `base/passive_trees/${version}.json` : 'base/passive_tree.json';
  if (!dataFiles[path]) throw new Error(`このパッシブツリーの版には対応していません：${version}`);
  if(treeCache.has(path))return treeCache.get(path);
  const nodes=JSON.parse(dataFiles[path]).map(n => ({skill:n.skill,name:n.name || n.id,kind:n.kind,x:n.x,y:n.y,connections:n.connections || [],stats:n.stats || [],ascendancy_id:n.ascendancy_id}));
  treeCache.set(path,nodes);return nodes;
}
const engineRequest=request=>({...request,items:(request.items||[]).map(item=>item.slot==='body'?{...item,slot:'bodyarmour'}:item)});
const calculate = request => {
  if (!validRequest(request)) throw new Error('構成の形式が正しくありません。');
  // Preserve the site's existing save-slot IDs; normalize only at the engine boundary.
  const normalized=engineRequest(request);
  const result=JSON.parse(engine.calculateBuildJson(JSON.stringify(normalized)));
  if(result.item_errors)result.item_errors=result.item_errors.map(error=>error.slot==='bodyarmour'?{...error,slot:'body'}:error);
  return result;
};
self.onmessage = async ({data:{id,action,payload}}) => {
  try {
    ready ||= boot(); await ready;
    let result;
    if (action === 'boot') result = {gems, uniques:uniques.map(({raw,...item})=>item), minions,
      meta:JSON.parse(dataFiles['base/passive_tree_meta.json']), tree:tree(), runtime:{release:runtime.release,dataVersion:runtime.dataVersion}};
    else if (action === 'calculate') result = calculate(payload);
    else if (action === 'tree') result = tree(payload);
    else if (action === 'edit') result = JSON.parse(engine.previewTreeEditJson(JSON.stringify({...payload,request:engineRequest(payload.request)})));
    else if(action==='equipment-audit'){
      if(!validRequest(payload.request)||!Array.isArray(payload.items)||payload.items.length>40)throw Error('装備条件を確認できません。');
      result=payload.items.flatMap(({slot,requirements:req})=>{
        const without=calculate({...payload.request,items:(payload.request.items || []).filter(i=>i.slot!==slot)});
        const available=id=>without.stats.find(s=>s.id===id)?.value ?? 0;
        const gaps=[];
        for(const [key,id,label]of [['str','Str','筋力'],['dex','Dex','器用さ'],['int','Int','知性']])if(Number.isFinite(req[key])&&req[key]>available(id))gaps.push(`${label}が${Math.ceil(req[key]-available(id))}不足（装備自身を除く${available(id)} / 必要${req[key]}）`);
        if(req.level>payload.request.character.level)gaps.push(`必要Lv${req.level}に未到達`);
        return gaps.map(message=>({slot,message}));
      });
    }
    else if (action === 'unique') {
      const raw=uniques.find(item=>item.id===payload.id)?.raw;
      if(!raw)throw new Error('ユニークが見つかりません。');
      const lines=raw.trimEnd().split('\n');
      const variants=lines.filter(line=>line.startsWith('Variant:')).length;
      const rolls=Object.fromEntries(lines.map((_,index)=>[index,Math.min(1,Math.max(0,payload.roll ?? .5))]));
      result = JSON.parse(engine.uniqueItemDraftJson(JSON.stringify({id:payload.id,...(variants?{variant:variants}:{}),rolls})));
    }
    else throw new Error('不明な操作です。');
    postMessage({id,result});
  } catch (error) {
    let message = error.message || String(error);
    try {message = JSON.parse(message).message || message;} catch {}
    postMessage({id,error:message,errorCode:error.code || (error instanceof WebAssembly.RuntimeError?'ENGINE_STARTUP_FAILURE':undefined)});
  }
};
