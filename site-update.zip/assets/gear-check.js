const STAGES = [[1,10,"Lv1〜10"],[11,20,"Lv11〜20"],[21,30,"Lv21〜30"],[31,40,"Lv31〜40"],[41,65,"Lv41〜キャンペーン終了"],[66,75,"Mapping開始"],[76,90,"Early Endgame"],[91,100,"Endgame完成"]];
const byId = (id) => document.getElementById(id);
let builds = [];
let committedLevel = 1;
const concernLabels = {death:"すぐ死ぬ",damage:"火力が低い",mana:"マナ不足",boss:"ボスが倒せない",speed:"周回が遅い",purchase:"何を買えばいいか分からない"};
const common = {
  death:["防具","属性耐性と現在レベルに合う防御値を確認","ブーツと回避手段"],
  damage:["武器","主力スキルに影響する能力と武器レベルを確認","サポート接続と操作順"],
  mana:["スキル設定","消費量と回復手段を確認","不要な常時効果とサポート"],
  boss:["操作順","単体用スキルと維持効果を確認","防御と回避時間"],
  speed:["ブーツ","移動速度と通常敵への攻撃回数を確認","主力の範囲と操作順"],
  purchase:["最も古い部位","困りごとに直結する1部位だけ比較","必要レベルと装備条件"]
};

function populateBuilds(className, selectedBuild = "") {
  const select = byId("gear-build");
  const matches = builds.filter((build) => build.className === className);
  select.replaceChildren(new Option(className ? "ビルドを選択" : "先に職業を選択", ""));
  matches.forEach((build) => select.append(new Option(build.name, build.id)));
  select.disabled = !className;
  select.value = matches.some((build) => build.id === selectedBuild) ? selectedBuild : (matches[0]?.id || "");
}

// Same stage resolution as the build page: exact band label first, then a level
// range written in the label (e.g. "Lv1〜13"), then the band position clamped to
// the build's own stage count. Builds using the fixed band labels only take the
// exact match.
function resolveStage(buildStages, bandIndex, stageLabel, level) {
  if (!buildStages?.length || bandIndex < 0) return undefined;
  const exact = buildStages.find((item) => item.label === stageLabel);
  if (exact) return exact;
  const byRange = buildStages.find((item) => {
    const range = /Lv\s*(\d+)\s*[〜~～\-–]\s*(\d+)/.exec(item.label || "");
    return range && level >= Number(range[1]) && level <= Number(range[2]);
  });
  return byRange || buildStages[Math.min(bandIndex, buildStages.length - 1)];
}

function render() {
  const build = builds.find((item) => item.id === byId("gear-build").value);
  const level = committedLevel;
  const concern = byId("gear-concern").value;
  const budget = byId("gear-budget").value;
  const bandIndex = STAGES.findIndex(([min,max]) => level >= min && level <= max);
  const stageLabel = STAGES[bandIndex]?.[2];
  const stage = resolveStage(build?.levelingStages, bandIndex, stageLabel, level);
  const base = common[concern];
  byId("gear-result-title").textContent = build ? `${build.name} / Lv${level}` : `Lv${level}の装備チェック`;
  byId("gear-context").textContent = `${stageLabel}・悩み：${concernLabels[concern]}・予算：${budget}`;
  const items = stage ? [
    ["最優先", stage.replaceGear || base[0], `確認する能力：${stage.gearPriority || base[1]}`],
    ["次", "主力スキルと装備条件", `理由：${stage.caution || base[2]}`],
    ["その次", "次の段階へ進む条件", `更新目安：${stage.transitionCondition}`]
  ] : [
    ["最優先", base[0], base[1]], ["次", base[2], "ビルド固有の数値ではなく一般確認です。"], ["その次", "公式トレードで比較", "固定相場を前提にせず、同条件の複数出品を比較してください。"]
  ];
  const list = byId("gear-actions");
  list.replaceChildren();
  items.forEach(([rank,title,reason]) => {
    const item = document.createElement("li");
    item.innerHTML = `<b></b><div><strong></strong><p></p></div>`;
    item.querySelector("b").textContent = rank;
    item.querySelector("strong").textContent = title;
    item.querySelector("p").textContent = reason;
    list.append(item);
  });
  byId("gear-data-note").textContent = stage ? "このレベル帯は掲載情報源から再構成したビルド固有案内です。" : "このレベル帯のビルド固有情報は未登録のため、一般的な確認手順を表示しています。";
  if (build) localStorage.setItem("poe2:navi:gear-build", build.id);
  localStorage.setItem("poe2:navi:gear-level", String(level));
}

fetch("/data/builds.json").then((response) => response.json()).then((data) => {
  builds = data.filter((build) => build.status !== "draft");
  [...new Set(builds.map((build) => build.className))].forEach((name) => byId("gear-class").append(new Option(name, name)));
  const params=new URLSearchParams(location.search);
  const savedBuild = params.get('build') || localStorage.getItem("poe2:navi:selected-build") || localStorage.getItem("poe2:navi:gear-build") || "";
  const savedClass = builds.find((build) => build.id === savedBuild)?.className || localStorage.getItem("poe2:navi:gear-class") || "";
  byId("gear-class").value = savedClass;
  populateBuilds(savedClass, savedBuild);
  const levelCandidates = [params.get('level'), localStorage.getItem("poe2:navi:gear-level"), localStorage.getItem('poe2:navi:quick-level')];
  committedLevel = levelCandidates.map(Number).find((level) => Number.isInteger(level) && level >= 1 && level <= 100) || 1;
  byId("gear-level").value = committedLevel;
  if(Object.hasOwn(common,params.get('concern')))byId('gear-concern').value=params.get('concern');
  render();
});
byId("gear-class").addEventListener("change", (event) => {
  localStorage.setItem("poe2:navi:gear-class", event.target.value);
  populateBuilds(event.target.value);
  render();
});
function commitLevelInput() {
  const input = byId("gear-level");
  const value = input.value.trim();
  const number = Number(value);
  const next = value !== "" && Number.isFinite(number) ? Math.max(1, Math.min(100, Math.trunc(number))) : committedLevel;
  input.value = next;
  if (next !== committedLevel) { committedLevel = next; render(); }
}
byId("gear-level").addEventListener("change", commitLevelInput);
byId("gear-level").addEventListener("blur", commitLevelInput);
byId("gear-level").addEventListener("keydown", (event) => {
  if (event.key === "Enter") { event.preventDefault(); commitLevelInput(); }
});
["gear-build","gear-concern","gear-budget"].forEach((id) => byId(id).addEventListener("input", render));
