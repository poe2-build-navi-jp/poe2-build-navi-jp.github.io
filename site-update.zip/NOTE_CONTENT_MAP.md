# note / X → POE2ビルドナビ 送客対応表

同じ本文を転載せず、noteでは特徴・選び方を説明し、サイトではLv1からの手順と現在Lv入力を提供します。トップではなく、投稿テーマに一致するURLへ直接送ります。

## 公開済みnote記事からの優先リンク

| note記事 | 記事URL | 最適なリンク先 | 計測用URL |
|---|---|---|---|
| Spirit Walker（ハントレス）ツイスタービルド完全ガイド | https://note.com/fresh_okapi3816/n/nbe96101eda53 | /builds/huntress/twister-spirit-walker/ | https://poe2-build-navi-jp.github.io/builds/huntress/twister-spirit-walker/?utm_source=note&utm_medium=referral&utm_campaign=huntress_twister_spirit_walker |
| グレネード・ジェムリング解説 | https://note.com/fresh_okapi3816/n/nfd9d6bfbb0d8 | /builds/mercenary/grenade-gemling/ | https://poe2-build-navi-jp.github.io/builds/mercenary/grenade-gemling/?utm_source=note&utm_medium=referral&utm_campaign=mercenary_grenade_gemling |
| 0.5.5 Tier比較 | https://note.com/fresh_okapi3816/n/n5c499efd7391 | /tier-list/ | https://poe2-build-navi-jp.github.io/tier-list/?utm_source=note&utm_medium=referral&utm_campaign=poe2_tier_055 |
| 1.0正式版の速報 | https://note.com/fresh_okapi3816/n/n8e50e45e6c73 | /poe2-1-0/ | https://poe2-build-navi-jp.github.io/poe2-1-0/?utm_source=note&utm_medium=referral&utm_campaign=poe2_1_0_news |
| 1.0無料化・初心者向けクラス | https://note.com/fresh_okapi3816/n/ne5263724eb0f | /classes/ | https://poe2-build-navi-jp.github.io/classes/?utm_source=note&utm_medium=referral&utm_campaign=poe2_1_0_beginner_classes |
| 0.5.5レベリング効率化 | https://note.com/fresh_okapi3816/n/nf6f8c2db6ed1 | /leveling/ | https://poe2-build-navi-jp.github.io/leveling/?utm_source=note&utm_medium=referral&utm_campaign=leveling_055 |
| 装備の優先順位 | https://note.com/fresh_okapi3816/n/n63f105b8740d | /guides/gear-upgrade/ | https://poe2-build-navi-jp.github.io/guides/gear-upgrade/?utm_source=note&utm_medium=referral&utm_campaign=gear_priority |
| マッピング最強ビルド3選 | https://note.com/fresh_okapi3816/n/nbd2ce44d8585 | /best-builds/ | https://poe2-build-navi-jp.github.io/best-builds/?utm_source=note&utm_medium=referral&utm_campaign=mapping_best_builds |
| 低予算ビルド3選 | https://note.com/fresh_okapi3816/n/n09f92db3dc1a | /best-builds/ | https://poe2-build-navi-jp.github.io/best-builds/?utm_source=note&utm_medium=referral&utm_campaign=budget_best_builds |
| ボスで詰まった時に見直す5項目 | https://note.com/fresh_okapi3816/n/nb6f6a2709e4a | /guides/cant-beat-boss/ | https://poe2-build-navi-jp.github.io/guides/cant-beat-boss/?utm_source=note&utm_medium=referral&utm_campaign=cant_beat_boss |

## 公開済み記事の修正候補

| 記事 | 残存箇所 | 差し替え先 |
|---|---|---|
| [1.0無料化・初心者向けクラス](https://note.com/fresh_okapi3816/n/ne5263724eb0f) | 「Ice Shot Deadeye 完全ロードマップ」の未設定URL | https://poe2-build-navi-jp.github.io/builds/ranger/ice-shot-deadeye/?utm_source=note&utm_medium=referral&utm_campaign=poe2_1_0_ice_shot |
| 同上 | 「Spirit Walker（ハントレス）ツイスター完全ガイド」の未設定URL | https://poe2-build-navi-jp.github.io/builds/huntress/twister-spirit-walker/?utm_source=note&utm_medium=referral&utm_campaign=poe2_1_0_spirit_walker |
| 同上 | 「ミニオン系初心者ビルドの選び方」の未設定URL | https://poe2-build-navi-jp.github.io/builds/witch/minion-infernalist/?utm_source=note&utm_medium=referral&utm_campaign=poe2_1_0_minion |

今回の公開検索で確認できたPoE2記事には、「有料記事」と誤解させる表記は見つかりませんでした。上の未設定URLは誤解や離脱につながるため、note側で差し替えが必要です。

ウィッチハンター比較・ストームウィーバー比較は、単一の育成手順と一致する個別ビルドがまだないため、無関係な個別ページへは送りません。

## 投稿テーマ別リンク

| 投稿テーマ | リンク先 | note用UTMリンク | X用UTMリンク |
|---|---|---|---|
| PoE2 最強・おすすめビルド | /best-builds/ | https://poe2-build-navi-jp.github.io/best-builds/?utm_source=note&utm_medium=referral&utm_campaign=best_builds | https://poe2-build-navi-jp.github.io/best-builds/?utm_source=x&utm_medium=social&utm_campaign=best_builds |
| PoE2 初心者向けTier | /tier-list/ | https://poe2-build-navi-jp.github.io/tier-list/?utm_source=note&utm_medium=referral&utm_campaign=poe2_tier | https://poe2-build-navi-jp.github.io/tier-list/?utm_source=x&utm_medium=social&utm_campaign=poe2_tier |
| PoE2 初心者おすすめ | /beginner-guide/ | https://poe2-build-navi-jp.github.io/beginner-guide/?utm_source=note&utm_medium=referral&utm_campaign=beginner_build | https://poe2-build-navi-jp.github.io/beginner-guide/?utm_source=x&utm_medium=social&utm_campaign=beginner_build |
| PoE2 リーグスターター | /league-starter/ | https://poe2-build-navi-jp.github.io/league-starter/?utm_source=note&utm_medium=referral&utm_campaign=league_starter | https://poe2-build-navi-jp.github.io/league-starter/?utm_source=x&utm_medium=social&utm_campaign=league_starter |
| PoE2 1.0 | /poe2-1-0/ | https://poe2-build-navi-jp.github.io/poe2-1-0/?utm_source=note&utm_medium=referral&utm_campaign=poe2_1_0 | https://poe2-build-navi-jp.github.io/poe2-1-0/?utm_source=x&utm_medium=social&utm_campaign=poe2_1_0 |
| PoE2 0.5.5ビルド | /guides/poe2-0-5-5-builds/ | https://poe2-build-navi-jp.github.io/guides/poe2-0-5-5-builds/?utm_source=note&utm_medium=referral&utm_campaign=poe2_0_5_5 | https://poe2-build-navi-jp.github.io/guides/poe2-0-5-5-builds/?utm_source=x&utm_medium=social&utm_campaign=poe2_0_5_5 |
| PoE2 Forbidden Rites初心者 | /guides/forbidden-rites-beginner/ | https://poe2-build-navi-jp.github.io/guides/forbidden-rites-beginner/?utm_source=note&utm_medium=referral&utm_campaign=forbidden_rites_beginner | https://poe2-build-navi-jp.github.io/guides/forbidden-rites-beginner/?utm_source=x&utm_medium=social&utm_campaign=forbidden_rites_beginner |
| PoE2 火力が出ない | /guides/increase-damage/ | https://poe2-build-navi-jp.github.io/guides/increase-damage/?utm_source=note&utm_medium=referral&utm_campaign=low_damage | https://poe2-build-navi-jp.github.io/guides/increase-damage/?utm_source=x&utm_medium=social&utm_campaign=low_damage |
| PoE2 すぐ死ぬ | /guides/why-i-die/ | https://poe2-build-navi-jp.github.io/guides/why-i-die/?utm_source=note&utm_medium=referral&utm_campaign=dying_too_much | https://poe2-build-navi-jp.github.io/guides/why-i-die/?utm_source=x&utm_medium=social&utm_campaign=dying_too_much |
| PoE2 装備更新 | /guides/gear-upgrade/ | https://poe2-build-navi-jp.github.io/guides/gear-upgrade/?utm_source=note&utm_medium=referral&utm_campaign=gear_upgrade | https://poe2-build-navi-jp.github.io/guides/gear-upgrade/?utm_source=x&utm_medium=social&utm_campaign=gear_upgrade |
| PoE2 マナ不足 | /guides/mana-problem/ | https://poe2-build-navi-jp.github.io/guides/mana-problem/?utm_source=note&utm_medium=referral&utm_campaign=mana_problem | https://poe2-build-navi-jp.github.io/guides/mana-problem/?utm_source=x&utm_medium=social&utm_campaign=mana_problem |
| PoE2 ボスに勝てない | /guides/cant-beat-boss/ | https://poe2-build-navi-jp.github.io/guides/cant-beat-boss/?utm_source=note&utm_medium=referral&utm_campaign=cant_beat_boss | https://poe2-build-navi-jp.github.io/guides/cant-beat-boss/?utm_source=x&utm_medium=social&utm_campaign=cant_beat_boss |
| PoE2 周回が遅い | /guides/slow-mapping/ | https://poe2-build-navi-jp.github.io/guides/slow-mapping/?utm_source=note&utm_medium=referral&utm_campaign=slow_mapping | https://poe2-build-navi-jp.github.io/guides/slow-mapping/?utm_source=x&utm_medium=social&utm_campaign=slow_mapping |
| PoE2 Mapping初心者 | /guides/mapping/ | https://poe2-build-navi-jp.github.io/guides/mapping/?utm_source=note&utm_medium=referral&utm_campaign=mapping_beginner | https://poe2-build-navi-jp.github.io/guides/mapping/?utm_source=x&utm_medium=social&utm_campaign=mapping_beginner |
| PoE2 パッシブの振り方 | /guides/passive-tree/ | https://poe2-build-navi-jp.github.io/guides/passive-tree/?utm_source=note&utm_medium=referral&utm_campaign=passive_tree | https://poe2-build-navi-jp.github.io/guides/passive-tree/?utm_source=x&utm_medium=social&utm_campaign=passive_tree |
| PoE2 耐性・すぐ死ぬ | /guides/resistance/ | https://poe2-build-navi-jp.github.io/guides/resistance/?utm_source=note&utm_medium=referral&utm_campaign=resistance | https://poe2-build-navi-jp.github.io/guides/resistance/?utm_source=x&utm_medium=social&utm_campaign=resistance |
| PoE2 1.0 公開日 | /poe2-1-0/release-date/ | https://poe2-build-navi-jp.github.io/poe2-1-0/release-date/?utm_source=note&utm_medium=referral&utm_campaign=poe2_1_0_release | https://poe2-build-navi-jp.github.io/poe2-1-0/release-date/?utm_source=x&utm_medium=social&utm_campaign=poe2_1_0_release |
| PoE2 始め方・無料化 | /poe2-1-0/how-to-start/ | https://poe2-build-navi-jp.github.io/poe2-1-0/how-to-start/?utm_source=note&utm_medium=referral&utm_campaign=poe2_how_to_start | https://poe2-build-navi-jp.github.io/poe2-1-0/how-to-start/?utm_source=x&utm_medium=social&utm_campaign=poe2_how_to_start |
| PoE2 必要スペック | /poe2-1-0/system-requirements/ | https://poe2-build-navi-jp.github.io/poe2-1-0/system-requirements/?utm_source=note&utm_medium=referral&utm_campaign=poe2_system_requirements | https://poe2-build-navi-jp.github.io/poe2-1-0/system-requirements/?utm_source=x&utm_medium=social&utm_campaign=poe2_system_requirements |
| PoE2 日本語対応 | /poe2-1-0/japanese/ | https://poe2-build-navi-jp.github.io/poe2-1-0/japanese/?utm_source=note&utm_medium=referral&utm_campaign=poe2_japanese | https://poe2-build-navi-jp.github.io/poe2-1-0/japanese/?utm_source=x&utm_medium=social&utm_campaign=poe2_japanese |
| PoE2 課金・スタッシュタブ | /poe2-1-0/microtransactions/ | https://poe2-build-navi-jp.github.io/poe2-1-0/microtransactions/?utm_source=note&utm_medium=referral&utm_campaign=poe2_microtransactions | https://poe2-build-navi-jp.github.io/poe2-1-0/microtransactions/?utm_source=x&utm_medium=social&utm_campaign=poe2_microtransactions |
| PoE2 コントローラー | /poe2-1-0/controller/ | https://poe2-build-navi-jp.github.io/poe2-1-0/controller/?utm_source=note&utm_medium=referral&utm_campaign=poe2_controller | https://poe2-build-navi-jp.github.io/poe2-1-0/controller/?utm_source=x&utm_medium=social&utm_campaign=poe2_controller |
| PoE2 事前登録 | /poe2-1-0/pre-registration/ | https://poe2-build-navi-jp.github.io/poe2-1-0/pre-registration/?utm_source=note&utm_medium=referral&utm_campaign=poe2_pre_registration | https://poe2-build-navi-jp.github.io/poe2-1-0/pre-registration/?utm_source=x&utm_medium=social&utm_campaign=poe2_pre_registration |
| PoE2 1.0 キャラ引き継ぎ | /poe2-1-0/carry-over/ | https://poe2-build-navi-jp.github.io/poe2-1-0/carry-over/?utm_source=note&utm_medium=referral&utm_campaign=poe2_carry_over | https://poe2-build-navi-jp.github.io/poe2-1-0/carry-over/?utm_source=x&utm_medium=social&utm_campaign=poe2_carry_over |
| PoE2 1.0ビルド対応状況 | /poe2-1-0/build-status/ | https://poe2-build-navi-jp.github.io/poe2-1-0/build-status/?utm_source=note&utm_medium=referral&utm_campaign=poe2_1_0_build_status | https://poe2-build-navi-jp.github.io/poe2-1-0/build-status/?utm_source=x&utm_medium=social&utm_campaign=poe2_1_0_build_status |
| PoE2 Duelist | /poe2-1-0/duelist/ | https://poe2-build-navi-jp.github.io/poe2-1-0/duelist/?utm_source=note&utm_medium=referral&utm_campaign=poe2_duelist | https://poe2-build-navi-jp.github.io/poe2-1-0/duelist/?utm_source=x&utm_medium=social&utm_campaign=poe2_duelist |
| PoE2 ExileCon 2026 | /poe2-1-0/exilecon-2026/ | https://poe2-build-navi-jp.github.io/poe2-1-0/exilecon-2026/?utm_source=note&utm_medium=referral&utm_campaign=poe2_exilecon_2026 | https://poe2-build-navi-jp.github.io/poe2-1-0/exilecon-2026/?utm_source=x&utm_medium=social&utm_campaign=poe2_exilecon_2026 |
| ワーリングアサルト・マーシャルアーティスト | /builds/monk/whirling-assault/ | https://poe2-build-navi-jp.github.io/builds/monk/whirling-assault/?utm_source=note&utm_medium=referral&utm_campaign=monk-whirling-assault | https://poe2-build-navi-jp.github.io/builds/monk/whirling-assault/?utm_source=x&utm_medium=social&utm_campaign=monk-whirling-assault |
| フォーリングサンダー・マーシャルアーティスト | /builds/monk/falling-thunder/ | https://poe2-build-navi-jp.github.io/builds/monk/falling-thunder/?utm_source=note&utm_medium=referral&utm_campaign=monk-falling-thunder | https://poe2-build-navi-jp.github.io/builds/monk/falling-thunder/?utm_source=x&utm_medium=social&utm_campaign=monk-falling-thunder |
| ツイスター・ジェムリング | /builds/mercenary/twister-gemling/ | https://poe2-build-navi-jp.github.io/builds/mercenary/twister-gemling/?utm_source=note&utm_medium=referral&utm_campaign=mercenary-twister-gemling | https://poe2-build-navi-jp.github.io/builds/mercenary/twister-gemling/?utm_source=x&utm_medium=social&utm_campaign=mercenary-twister-gemling |
| シールドウォール・スミス | /builds/warrior/shield-wall-smith/ | https://poe2-build-navi-jp.github.io/builds/warrior/shield-wall-smith/?utm_source=note&utm_medium=referral&utm_campaign=warrior-shield-wall-smith | https://poe2-build-navi-jp.github.io/builds/warrior/shield-wall-smith/?utm_source=x&utm_medium=social&utm_campaign=warrior-shield-wall-smith |
| 砂と炎のヴァラシュタ | /builds/sorceress/sand-and-fire/ | https://poe2-build-navi-jp.github.io/builds/sorceress/sand-and-fire/?utm_source=note&utm_medium=referral&utm_campaign=sorceress-sand-fire | https://poe2-build-navi-jp.github.io/builds/sorceress/sand-and-fire/?utm_source=x&utm_medium=social&utm_campaign=sorceress-sand-fire |
| 相棒スピリットウォーカー | /builds/huntress/companion/ | https://poe2-build-navi-jp.github.io/builds/huntress/companion/?utm_source=note&utm_medium=referral&utm_campaign=huntress-companion | https://poe2-build-navi-jp.github.io/builds/huntress/companion/?utm_source=x&utm_medium=social&utm_campaign=huntress-companion |
| ミニオン・スピリットウォーカー | /builds/huntress/minion-spirit-walker/ | https://poe2-build-navi-jp.github.io/builds/huntress/minion-spirit-walker/?utm_source=note&utm_medium=referral&utm_campaign=huntress-minion-spirit-walker | https://poe2-build-navi-jp.github.io/builds/huntress/minion-spirit-walker/?utm_source=x&utm_medium=social&utm_campaign=huntress-minion-spirit-walker |
| アイスショット・デッドアイ | /builds/ranger/ice-shot-deadeye/ | https://poe2-build-navi-jp.github.io/builds/ranger/ice-shot-deadeye/?utm_source=note&utm_medium=referral&utm_campaign=ranger-ice-shot-deadeye | https://poe2-build-navi-jp.github.io/builds/ranger/ice-shot-deadeye/?utm_source=x&utm_medium=social&utm_campaign=ranger-ice-shot-deadeye |
| スナイパーミニオン・インファーナリスト | /builds/witch/minion-infernalist/ | https://poe2-build-navi-jp.github.io/builds/witch/minion-infernalist/?utm_source=note&utm_medium=referral&utm_campaign=witch-minion-infernalist | https://poe2-build-navi-jp.github.io/builds/witch/minion-infernalist/?utm_source=x&utm_medium=social&utm_campaign=witch-minion-infernalist |
| 植物オラクル | /builds/druid/plant-oracle/ | https://poe2-build-navi-jp.github.io/builds/druid/plant-oracle/?utm_source=note&utm_medium=referral&utm_campaign=druid-plant-oracle | https://poe2-build-navi-jp.github.io/builds/druid/plant-oracle/?utm_source=x&utm_medium=social&utm_campaign=druid-plant-oracle |
| グリムピラー（スペルトーテム）・オラクル | /builds/druid/grim-pillars-oracle/ | https://poe2-build-navi-jp.github.io/builds/druid/grim-pillars-oracle/?utm_source=note&utm_medium=referral&utm_campaign=druid-grim-pillars-oracle | https://poe2-build-navi-jp.github.io/builds/druid/grim-pillars-oracle/?utm_source=x&utm_medium=social&utm_campaign=druid-grim-pillars-oracle |
| ED・コンテージョン リッチ | /builds/witch/ed-contagion-lich/ | https://poe2-build-navi-jp.github.io/builds/witch/ed-contagion-lich/?utm_source=note&utm_medium=referral&utm_campaign=witch-ed-contagion-lich | https://poe2-build-navi-jp.github.io/builds/witch/ed-contagion-lich/?utm_source=x&utm_medium=social&utm_campaign=witch-ed-contagion-lich |
| グレネード・ジェムリング | /builds/mercenary/grenade-gemling/ | https://poe2-build-navi-jp.github.io/builds/mercenary/grenade-gemling/?utm_source=note&utm_medium=referral&utm_campaign=mercenary-grenade-gemling | https://poe2-build-navi-jp.github.io/builds/mercenary/grenade-gemling/?utm_source=x&utm_medium=social&utm_campaign=mercenary-grenade-gemling |
| ツイスター・スピリットウォーカー | /builds/huntress/twister-spirit-walker/ | https://poe2-build-navi-jp.github.io/builds/huntress/twister-spirit-walker/?utm_source=note&utm_medium=referral&utm_campaign=huntress-twister-spirit-walker | https://poe2-build-navi-jp.github.io/builds/huntress/twister-spirit-walker/?utm_source=x&utm_medium=social&utm_campaign=huntress-twister-spirit-walker |
| スパーク・ストームウィーバー | /builds/sorceress/spark-stormweaver/ | https://poe2-build-navi-jp.github.io/builds/sorceress/spark-stormweaver/?utm_source=note&utm_medium=referral&utm_campaign=sorceress-spark-stormweaver | https://poe2-build-navi-jp.github.io/builds/sorceress/spark-stormweaver/?utm_source=x&utm_medium=social&utm_campaign=sorceress-spark-stormweaver |

CTA例：

- Lv1から完成までの育成手順はこちら
- 現在Lvから次にやることを見る
- 装備・スキル・パッシブまでまとめて確認
