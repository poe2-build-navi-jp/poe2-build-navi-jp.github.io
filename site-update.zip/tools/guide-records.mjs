import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
const root = resolve(import.meta.dirname, '..');
// Wide screenshots have smaller copies next to them (name-800w.webp and name-1280w.webp, made by
// tools/make-screenshot-variants.mjs). The browser picks the one that fits the screen; the link still opens the original.
export const SCREENSHOT_WIDTHS = [800, 1280];
export const screenshotCopy = (src, width) => src.replace(/\.webp$/, `-${width}w.webp`);
const srcset = image => {
  const widths = SCREENSHOT_WIDTHS.filter(width => width < image.width);
  if (!(image.width > 1000) || !widths.every(width => existsSync(resolve(root, '.' + screenshotCopy(image.src, width))))) return '';
  return ` srcset="${[...widths.map(width => `${esc(screenshotCopy(image.src, width))} ${width}w`), `${esc(image.src)} ${image.width}w`].join(', ')}" sizes="(max-width: 900px) calc(100vw - 32px), 860px"`;
};
const esc = value => String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');

// Screenshot transcriptions are plain text, never executable HTML.
// A cell may be { text, href } to render an internal link; plain strings stay plain text.
const cellHtml = cell => {
  if (cell && typeof cell === 'object') {
    if (!cell.text || !/^\/(?:[a-z0-9-]+\/)+$/.test(cell.href || '')) throw new Error('Invalid guide record table link cell');
    return `<a href="${esc(cell.href)}">${esc(cell.text)}</a>`;
  }
  return esc(cell);
};
export function recordTable(table) {
  if (!table) return '';
  if (!table.caption || !table.headers?.length || !table.rows?.length || table.rows.some(row => row.length !== table.headers.length)) throw new Error('Invalid guide record table');
  return `${table.headers.length>2?'<p class="guide-record-scroll-hint">装備の表は横にスクロールして読めます。</p>':''}<div class="guide-record-table${table.headers.length>2?' guide-record-table-wide':''}" role="region" aria-label="${esc(table.caption)}" tabindex="0"><table><caption>${esc(table.caption)}</caption><thead><tr>${table.headers.map(header => `<th scope="col">${esc(header)}</th>`).join('')}</tr></thead><tbody>${table.rows.map(row => `<tr>${row.map((cell, index) => index === 0 ? `<th scope="row">${cellHtml(cell)}</th>` : `<td>${cellHtml(cell)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

// Game screenshots must not inherit the site's original-diagram licensing claims.
export function recordScreenshots(images = [], disclosure) {
  const figures = images.map(image => {
    if (!image.src?.startsWith('/images/') || !image.alt || !image.caption || !(image.width > 0) || !(image.height > 0)) throw new Error('Invalid guide screenshot');
    return `<figure class="guide-record-image"><a href="${esc(image.src)}" aria-label="拡大：${esc(image.alt)}"><img src="${esc(image.src)}"${srcset(image)} alt="${esc(image.alt)}" width="${image.width}" height="${image.height}" loading="lazy" decoding="async"></a><figcaption>${esc(image.caption)} <a href="${esc(image.src)}">画像を拡大</a>。提供スクリーンショット／ゲーム内画像：Grinding Gear Games。</figcaption></figure>`;
  }).join('');
  return disclosure && images.length ? `<details class="guide-record-gallery"><summary>${esc(disclosure)}</summary>${figures}</details>` : figures;
}

export function recordSimulatorLink(guide){
 const ids={'arbiter-of-divinity':'record-divinity','xesht':'record-xesht','arbiter-of-ash-clear-record':'record-ash'},id=ids[guide.slug];
 if(!id)return '';
 return `<aside class="content-action record-simulator"><h2>掲載装備を自分の構成と比較する</h2><p>確認できた装備の効果をシミュレーターへ取り込めます。未確認のスキル・パッシブ・予約設定は空欄です。最初に読み込み内容を確認し、今の作業を退避してから切り替えられます。</p><a class="button-secondary" href="/simulator/?build=mercenary-twister-gemling&amp;example=${id}&amp;from=record">撃破装備の読み込み内容を見る</a>${guide.slug==='xesht'?'<p>ゼシュト撃破時のLvは未確認です。画面で入力するLvは試算用です。</p>':''}</aside>`;
}
