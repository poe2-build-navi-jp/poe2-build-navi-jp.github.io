import {applyMobileSummary} from './mobile-summary.mjs';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {esc,facts,factsHtml,rows} from './build-facts.mjs';
import {insertBlock} from './block-order.mjs';
const root=resolve(import.meta.dirname,'..');
const read=p=>readFile(resolve(root,p),'utf8');
const save=(p,s)=>writeFile(resolve(root,p),s);
const builds=JSON.parse(await read('data/builds.json')).filter(b=>b.status!=='draft');
const discovery=JSON.parse(await read('data/discovery.json'));
const site=JSON.parse(await read('data/site.json'));
const url=b=>`/builds/${b.classSlug}/${b.slug}/`;
// Home: every listed build, grouped by how it fights, as crawlable text plus an ItemList. Each build
// appears once; the group follows its main skill type (Attack with a ranged weapon / melee Attack /
// Spell / Minion or Companion). JS shows one group at a time (tabs); without JS all groups are shown.
const HOME_GROUPS=[
 ['ranged','遠距離','弓・クロスボウ・槍で離れて戦う',['ranger-ice-shot-deadeye','mercenary-twister-gemling','huntress-twister-spirit-walker','mercenary-grenade-gemling']],
 ['melee','近接','近づいて武器や盾で戦う',['monk-whirling-assault','warrior-shield-wall-smith','monk-falling-thunder','monk-hollow-focus-storm-wave','warrior-shield-wall-warbringer']],
 ['spell','魔法','スペル（魔法）を撃って戦う',['sorceress-spark-stormweaver','druid-plant-oracle','druid-grim-pillars-oracle','witch-ed-contagion-lich']],
 ['minion','召喚','召喚した仲間や相棒に戦わせる',['witch-minion-infernalist','sorceress-sand-fire','huntress-companion','huntress-minion-spirit-walker','monk-infernal-legion-chayula','mercenary-supporting-fire-tactician']]
];
const tierOf=id=>Object.entries(discovery.tiers).find(([,list])=>list.some(t=>t.id===id))?.[0];
function homeBuildsHtml(){
 const listed=builds.filter(b=>b.status!=='draft');
 const grouped=HOME_GROUPS.map(([key,label,hint,ids])=>[key,label,hint,ids.map(id=>listed.find(b=>b.id===id)).filter(Boolean)]);
 const placed=new Set(grouped.flatMap(g=>g[3].map(b=>b.id)));
 const missing=listed.filter(b=>!placed.has(b.id));
 if(missing.length)throw new Error(`Home build groups miss: ${missing.map(b=>b.id).join(', ')}`);
 const top=listed.filter(b=>tierOf(b.id)==='S');
 const row=b=>`<li><a href="${url(b)}">${esc(b.name)}</a><span class="hb-meta">${esc(b.className)}・${esc(b.ascendancy)}／主力：${esc(b.mainSkill)}${tierOf(b.id)?`／初心者Tier ${tierOf(b.id)}`:''}</span><span class="hb-fit">${esc(b.audience)}</span></li>`;
 const schema={'@context':'https://schema.org','@type':'ItemList',name:`PoE2 ${discovery.patchVersion} おすすめビルド一覧`,numberOfItems:listed.length,itemListElement:grouped.flatMap(g=>g[3]).map((b,i)=>({'@type':'ListItem',position:i+1,name:b.name,url:`${site.baseUrl}${url(b)}`}))};
 return `<!-- home-builds:start --><section id="home-builds" class="section" aria-labelledby="home-builds-title"><div class="section-head"><p class="section-kicker">ALL BUILDS / ${esc(discovery.patchVersion)}</p><h2 id="home-builds-title">PoE2のおすすめビルド一覧（全${listed.length}ビルド）</h2><p class="hb-answer">POE2ビルドナビは、Path of Exile 2（PoE2）のビルドを日本語で比較できるビルドサイトです。${esc(discovery.patchVersion)}に対応した${listed.length}ビルドを、遠距離・近接・魔法・召喚の戦い方から選べます。初めて遊ぶ人は、初心者向けTierでSの${top.map(b=>esc(b.name)).join('・')}から選ぶと迷いにくくなります。</p></div><div class="hb-tabs" role="tablist" aria-label="戦い方を選ぶ" hidden>${grouped.map(([key,label,,list],i)=>`<button type="button" role="tab" id="hb-tab-${key}" aria-controls="hb-${key}" aria-selected="${i===0}">${label}<small>${list.length}</small></button>`).join('')}</div>${grouped.map(([key,label,hint,list])=>`<div class="hb-panel" id="hb-${key}" role="tabpanel" aria-labelledby="hb-tab-${key}"><h3>${label}<small>${hint}</small></h3><ul class="hb-list">${list.map(row).join('')}</ul></div>`).join('')}<p class="hb-more">「最強ビルド」は周回・ボス・予算などの目的で変わります。<a href="/best-builds/">目的別の最強ビルド比較</a>・<a href="/tier-list/">初心者向けTier</a>・<a href="/builds/">全ビルドの条件を比較</a></p><script type="application/ld+json">${JSON.stringify(schema).replaceAll('<','\\u003c')}</script><script defer src="/assets/home-builds.js"></script></section><!-- home-builds:end -->`;
}
const pages=['index.html','beginner-builds/index.html','builds/index.html','tier-list/index.html','league-starter/index.html','classes/index.html','leveling/index.html',...[...new Set(builds.map(b=>b.classSlug))].map(c=>`classes/${c}/index.html`)];
for(const page of pages){
 let html=await read(page);
 html=html.replace(/<article\b(?=[^>]*class="(?:catalog-card|class-build-card|build-card|quick-pick-card|discovery-card|purpose-card|tier-card|starter-card)\b)[^>]*>[\s\S]*?<\/article>/g,article=>{
  if(/class="early-build-card/.test(article))return article.replace(/<dl class="unified-facts">[\s\S]*?<\/dl>/g,'');
  const b=builds.find(b=>article.includes(`href="${url(b)}`));
  if(!b)return article;
  if(page==='beginner-builds/index.html' && /class="purpose-card"/.test(article)){
   const heading=article.match(/<p class="section-kicker">[\s\S]*?<\/h3>/)?.[0] || `<h3>${esc(b.name)}</h3>`;
   const values=new Map(rows(b,discovery));
   const compact=[['向いている人',b.audience],['弱点',b.weaknesses[0]],['切替時期',values.get('主力への切替目安')]];
   return `<article class="purpose-card">${heading}<dl class="quick-choice-facts">${compact.map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl><a class="button" href="${url(b)}">このビルドを確認する</a><details class="quick-choice-sources"><summary>確認資料・詳しい条件</summary>${factsHtml(b,discovery)}<p><a href="${url(b)}#source-list">原典一覧を確認する</a></p></details></article>`;
  }
  article=article.replace(/<details class="card-facts"><summary>[^<]*<\/summary>([\s\S]*?)<\/details>/g,'$1');
  article=article.replace(/<dl\b[^>]*>[\s\S]*?<\/dl>/g,'').replace(/<p class="fact-source">[\s\S]*?<\/p>/g,'');
  article=article.replace(/<button[^>]*data-compare[^>]*>[\s\S]*?<\/button>/g,'');
  // Tier and starter cards already summarise each build, so the full fact list starts closed there.
  const collapse=page==='tier-list/index.html'||page==='league-starter/index.html';
  const factBlock=collapse?`<details class="card-facts"><summary>詳しい条件・確認資料を見る</summary>${factsHtml(b,discovery)}</details>`:factsHtml(b,discovery);
  article=article.replace('</article>',`${factBlock}${page==='builds/index.html'?`<button type="button" data-compare="${esc(b.id)}" aria-pressed="false" hidden>比較に追加</button>`:''}</article>`);
  if(page==='builds/index.html'){
   const f=facts(b,discovery);
   article=article.replace(/ data-(build-id|styles|beginner|operation|ssf|unlock)="[^"]*"/g,'').replace('<article ',`<article data-build-id="${b.id}" data-styles="${f.styles.join(',')}" data-beginner="${f.beginner}" data-operation="${f.operation}" data-ssf="${b.ssf===true}" data-unlock="${f.switchLevel||''}" `);
  }
  return article;
 });
 html=html.replace(/<!-- build-ux:start -->[\s\S]*?<!-- build-ux:end -->/g,'');
 html=insertBlock(html,'</head>','build-ux','<!-- build-ux:start --><link rel="stylesheet" href="/assets/build-ux.css?v=1"><script type="module" src="/assets/build-ux.js?v=1"></script><!-- build-ux:end -->');
 if(page==='index.html'){
  html=html.replace(/<div class="hero-actions"[^>]*>[\s\S]*?<\/div>/,`<div class="hero-actions" aria-label="まず何をしたい？"><a class="button" href="/beginner-builds/">初心者おすすめビルド</a><a class="button-secondary" href="/best-builds/">最強ビルドを目的別に比較</a><a class="button-secondary" href="/guides/build-tier-list/">最強ビルドTier表（S〜D）</a><a class="button-secondary" href="/classes/">自分に合う職業を選ぶ</a><a class="button-secondary" href="/leveling/">現在Lvから続きを見る</a></div>`);
  const quick=html.match(/<section id="quick-start"[\s\S]*?<\/section>/)?.[0];
  html=html.replace(/<!-- home-builds:start -->[\s\S]*?<!-- home-builds:end -->/g,'');
  if(quick)html=html.replace(quick,'');
  html=html.replace(/(<section id="purpose-picks"[\s\S]*?<\/section>)/,`$1${homeBuildsHtml()}${quick||''}`);
  html=html.replace('id="quality-title">目的から探す','id="quality-title">もっと詳しく探す');
  html=html.replace(/<!-- recent-builds:start -->[\s\S]*?<!-- recent-builds:end -->/g,'');
  const recent=[...builds].sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt)).slice(0,3);
  const changes=builds.flatMap(b=>(b.changeHistory||[]).filter(r=>r.date&&r.summary?.trim()).map(r=>({b,...r}))).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,3);
  const recentHtml=`<!-- recent-builds:start --><section class="section" id="recent-changes"><h2>最近の変更</h2><p>表示・評価を変更した日と理由です。育成手順全体の資料確認日とは別に記録しています。</p><ul>${changes.map(r=>`<li><time datetime="${esc(r.date)}">${esc(r.date)}</time> <a href="${url(r.b)}#update-history">${esc(r.b.name)}</a>：${esc(r.summary)}</li>`).join('')}</ul><details><summary>最近のビルド資料確認</summary><p>以下は育成資料の確認日です。個別の修正日は上の「最近の変更」を参照してください。</p><ul>${recent.map(b=>`<li><a href="${url(b)}#update-history">${esc(b.name)}</a>：${esc(b.updatedAt)} 資料確認</li>`).join('')}</ul></details></section><!-- recent-builds:end -->`;
  html=html.replace(/(<section id="quick-start"[\s\S]*?<\/section>)/,`$1${recentHtml}`);
 }
 if(page==='builds/index.html'){
  html=html.replace(/<!-- comparison:start -->[\s\S]*?<!-- comparison:end -->/g,'');
  const selects=[['style','戦い方',['近接','遠距離','魔法','召喚']],['beginner','初心者',['初心者向け']],['ssf','SSF',['確認済のみ']],['operation','操作量',['少なめ','中','多め','未評価']],['unlock','主力への切替目安',['Lv1から','Lv20まで','Lv40まで','Lv41以降','未確認']]];
  const filters=`<!-- comparison:start --><section id="advanced-filters" hidden><h2>条件で絞る・最大3ビルドを比較</h2><p>未評価は低評価を意味しません。切替目安は育成手順に明記されたものだけで絞ります。スキル使用可能Lvとは異なります。</p><div class="ux-filters">${selects.map(([id,label,options])=>`<label>${label}<select id="filter-${id}"><option value="">すべて</option>${options.map(o=>`<option>${o}</option>`).join('')}</select></label>`).join('')}</div><button type="button" id="reset-filters">全ビルドを見る</button><p id="filter-empty" hidden>条件に一致するビルドはありません。<button type="button" id="relax-filter">条件を1つ外す</button></p><p id="compare-status" role="status" aria-live="polite">比較：0 / 3件</p><button type="button" id="show-compare">選択したビルドを比較</button><section id="build-comparison" tabindex="-1" hidden><h2>選択したビルドの比較</h2><div id="comparison-cards" class="ux-comparison"></div></section></section><!-- comparison:end -->`;
  html=html.replace('<div id="build-list"',`${filters}<div id="build-list"`);
 }
 html=html.replace(/\/assets\/(app|catalog-static)\.js(?:\?[^"']*)?/g,'/assets/$1.js?v=ux-20260926');
 if(page==='index.html' || page==='beginner-builds/index.html') html=applyMobileSummary(html,page==='beginner-builds/index.html');
 await save(page,html);
}
for(const b of builds){
 const path=`builds/${b.classSlug}/${b.slug}/index.html`;
 let html=await read(path);
 html=html.replace(/対応環境 [^<]+・<a href="[^"]+" target="_blank" rel="noopener noreferrer">最新確認 [^<]+<\/a>・最終確認 [^<]+/,`対応環境 ${esc(b.version)}・<a href="${esc(site.latestPatchSource)}" target="_blank" rel="noopener noreferrer">公式パッチノート確認 ${esc(site.latestPatchCheckedAt)}</a>・育成手順の原典照合 ${esc(b.updatedAt)}`);
 html=html.replace(/<div id="fact-grid" class="fact-grid">[\s\S]*?(?=<section id="level-card")/,`<div id="fact-grid" class="fact-grid"><div class="fact">対応パッチ：${esc(b.version)}</div><div class="fact">育成手順の原典照合：${esc(b.updatedAt)}</div>${b.mainSkillTiming?`<div class="fact"><small>主力スキル使用条件</small><b>${esc(b.mainSkillTiming.available)}</b></div><div class="fact"><small>主力への切替目安</small><b>${esc(b.mainSkillTiming.recommendedSwitch)}</b></div>`:''}</div></div>\n        `);
 if(!html.includes('id="now-action-guidance"'))html=html.replace('<p id="now-next"', '<p id="now-action-guidance" class="next-advice" hidden></p><p id="now-next"');
 html=html.replace('id="now-action-guidance" class="disclaimer"','id="now-action-guidance" class="next-advice"');
 html=html.replace(/<!-- build-history:start -->[\s\S]*?<!-- build-history:end -->/g,'');
 if(b.reviewedFacts?.ssfNote)html=html.replace(/(<b>SSF：<\/b>)未確認/,`$1${esc(b.reviewedFacts.ssfNote)}`);
 const records=(b.changeHistory||[]).map(r=>`<li><time>${esc(r.date)}</time> ${esc(r.summary)}</li>`).join('');
 const review=b.reviewedFacts;
 const reviewedItems=review?[['操作難易度',review.difficulty],['操作量',review.operation],['装備の条件',review.gearDependence],['SSF',review.ssfNote]].filter(([,value])=>value).map(([label,value])=>`<li>${esc(label)}：${esc(value)}</li>`).join(''):'';
 const reviewHtml=review?`<p>${esc(review.checkedAt)}：元ガイドの比較項目を追加確認しました。育成${b.levelingStages.length}段階の全内容を再検証した日付ではありません。</p><ul>${reviewedItems}</ul><p><a href="${esc(review.source)}" target="_blank" rel="noopener noreferrer">確認した元ガイドを見る</a></p>`:'';
 html=insertBlock(html,'</main>','build-history',`<!-- build-history:start --><section id="update-history" class="section"><h2>資料確認・更新履歴</h2><p>ビルド資料確認日：${esc(b.updatedAt)}／対応 ${esc(b.version)}。過去の具体的な変更理由は記録されていません。</p>${records?`<ul>${records}</ul>`:''}${reviewHtml}<p>2026-09-26：比較項目・再訪導線を整備。ゲーム内の育成内容を再検証した日ではありません。</p><a href="/builds/#advanced-filters">他のビルドと比較する</a> ・ <a href="/leveling/">別のLv・ビルドから探す</a></section><script type="module" src="/assets/build-ux.js?v=1"></script><!-- build-history:end -->`);
 html=html.replace(/<p id="build-update-notice"[^>]*><\/p>/g,'').replace('<section id="now"','<p id="build-update-notice" role="status" hidden></p><section id="now"');
 html=html.replace(/\/assets\/detail\.js(?:\?[^"']*)?/g,'/assets/detail.js?v=ux-20260926');
 await save(path,html);
}
console.log('Build UX: shared cards, filters, comparison, history, resume');
